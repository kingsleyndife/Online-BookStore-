﻿using E_BookWebApp.Pages.Staff;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Data.SqlClient;

namespace E_BookWebApp.Pages
{
    public class IndexModel : PageModel
    {
        public List<BookInfo> listNewestBooks = new List<BookInfo>();
        public List<BookInfo> listTopsales = new List<BookInfo>();
        public void OnGet()
        {
            try 
            {
                string connectionstring = "Data Source=.\\sqlexpress;Initial Catalog=E-BookWebApp;Integrated Security=True";

                using (SqlConnection connection = new SqlConnection(connectionstring))
                {
                    connection.Open();

                    string sql = "SELECT TOP 4 * FROM books ORDER BY created_at DESC";

                    using (SqlCommand command = new SqlCommand(sql, connection))
                    { 
                      using (SqlDataReader reader = command.ExecuteReader()) 
                      {
                        while(reader.Read()) 
                        {
                         
                                BookInfo bookInfo = new BookInfo();
                                bookInfo.Id = reader.GetInt32(0);
                                bookInfo.Title = reader.GetString(1);
                                bookInfo.Author = reader.GetString(2);
                                bookInfo.Isbn = reader.GetString(3);
                                bookInfo.Publication_year = reader.GetInt32(4);
                                bookInfo.Price = reader.GetDecimal(5);
                                bookInfo.Genere = reader.GetString(6);
                                bookInfo.Description = reader.GetString(7);
                                bookInfo.Book_status = reader.GetString(8);
                                bookInfo.Image_filename = reader.GetString(9);
                                bookInfo.Created_at = reader.GetDateTime(10).ToString("MM/dd/yyyy");

                                listNewestBooks.Add(bookInfo);

                            }
                        
                      }

                    }


                    sql = "SELECT TOP 4 books.*, (" +
                      "SELECT SUM(order_items.quantity) FROM order_items WHERE books.id = order_items.book_id" +
                      ") AS total_sales " +
                      "FROM books " +
                      "ORDER BY total_sales DESC";

                    using (SqlCommand command = new SqlCommand( sql, connection))
                    {
                        using (SqlDataReader reader = command.ExecuteReader()) 
                        {
                            while (reader.Read()) 
                            {

                                BookInfo bookInfo = new BookInfo();
                                bookInfo.Id = reader.GetInt32(0);
                                bookInfo.Title = reader.GetString(1);
                                bookInfo.Author = reader.GetString(2);
                                bookInfo.Isbn = reader.GetString(3);
                                bookInfo.Publication_year = reader.GetInt32(4);
                                bookInfo.Price = reader.GetDecimal(5);
                                bookInfo.Genere = reader.GetString(6);
                                bookInfo.Description = reader.GetString(7);
                                bookInfo.Book_status = reader.GetString(8);
                                bookInfo.Image_filename = reader.GetString(9);
                                bookInfo.Created_at = reader.GetDateTime(10).ToString("MM/dd/yyyy");

                                listTopsales.Add(bookInfo);

                            }


                        }
                      
                    }

                }
            
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            
            }
        }
    }
}