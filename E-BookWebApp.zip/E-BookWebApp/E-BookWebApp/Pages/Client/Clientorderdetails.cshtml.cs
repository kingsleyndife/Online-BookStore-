using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using static E_BookWebApp.Pages.Staff.OrderModel;
using System.Data.SqlClient;
using E_BookWebApp.Auth_Attributes;

namespace E_BookWebApp.Pages.Client
{

    [RequireAuth(RequiredRole = "customer")]
    public class ClientorderdetailsModel : PageModel
    {
        public OrderInfo orderInfo = new OrderInfo();

        public int page = 1; // the current html page
        public int totalPages = 0;
        private readonly int pageSize = 3; // orders per page


        public void OnGet(int id)
        {
            int customer_id = HttpContext.Session.GetInt32("id") ?? 0;

            if (id < 1)
            {
                Response.Redirect("/Client/Orders/Listofclientorder");
                return;
            }


            try
            {
                string connectionString = "Data Source=.\\sqlexpress;Initial Catalog=E-BookWebApp;Integrated Security=True";
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();


                    string sql = "SELECT * FROM orders WHERE id=@id AND customer_id=@customer_id";
                    using (SqlCommand command = new SqlCommand(sql, connection))
                    {
                        command.Parameters.AddWithValue("@id", id);
                        command.Parameters.AddWithValue("@customer_id", customer_id);

                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                orderInfo.id = reader.GetInt32(0);
                                orderInfo.customer_id = reader.GetInt32(1);
                                orderInfo.orderDate = reader.GetDateTime(2).ToString("MM/dd/yyyy");
                                orderInfo.shippingFee = reader.GetDecimal(3);
                                orderInfo.deliveryAddress = reader.GetString(4);
                                orderInfo.paymentMethod = reader.GetString(5);
                                orderInfo.paymentStatus = reader.GetString(6);
                                orderInfo.orderStatus = reader.GetString(7);

                                orderInfo.items = OrderInfo.getOrderItems(orderInfo.id);
                            }
                            else
                            {
                                Response.Redirect("/Client/Orders/Listofclient");
                                return;
                            }
                        }
                    }


                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);

            }







        }
    }
}
