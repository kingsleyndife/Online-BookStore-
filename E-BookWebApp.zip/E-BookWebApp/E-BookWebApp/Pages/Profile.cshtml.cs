using E_BookWebApp.Auth_Attributes;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.ComponentModel.DataAnnotations;
using System.Data.SqlClient;
using System.Net;

namespace E_BookWebApp.Pages
{
    [RequireAuth]
	[BindProperties]
    public class ProfileModel : PageModel
    {
		[Required(ErrorMessage = "The First Name is required")]
		public string Firstname { get; set; } = "";

		[Required(ErrorMessage = "The Last Name is required")]
		public string Lastname { get; set; } = "";

		[Required(ErrorMessage = "The Email is required"), EmailAddress]
		public string Email { get; set; } = "";

		public string? Phone { get; set; } = "";



		public string? Password { get; set; } = "";
		public string? ConfirmPassword { get; set; } = "";



		public string errorMessage = "";
		public string successMessage = "";
		public void OnGet()
        {

				Firstname = HttpContext.Session.GetString("firstname") ?? "";
				Lastname = HttpContext.Session.GetString("lastname") ?? "";
				Email = HttpContext.Session.GetString("email") ?? "";
				Phone = HttpContext.Session.GetString("phone");
				
		}

		public void OnPost() 
		{
			if (!ModelState.IsValid)
			{
				errorMessage = "Data validation failed";
				return;
			}

			// successful data validation
			if (Phone == null) Phone = "";


			//Uodate the user profile  or the password 

			string submitButton = Request.Form["action"];

			string connectionString = "Data Source=.\\sqlexpress;Initial Catalog=E-BookWebApp;Integrated Security=True";

			if (submitButton.Equals("profile"))
			{
				// update the user profile in the database
				try
				{
					using (SqlConnection connection = new SqlConnection(connectionString))
					{
						connection.Open();

						string sql = "UPDATE users SET firstname=@firstname, lastname=@lastname, " +
							"email=@email, phone=@phone  WHERE id=@id";

						int? id = HttpContext.Session.GetInt32("id");
						using (SqlCommand command = new SqlCommand(sql, connection))
						{
							command.Parameters.AddWithValue("@firstname", Firstname);
							command.Parameters.AddWithValue("@lastname", Lastname);
							command.Parameters.AddWithValue("@email", Email);
							command.Parameters.AddWithValue("@phone", Phone);
							command.Parameters.AddWithValue("@id", id);

							command.ExecuteNonQuery();
						}
					}
				}
				catch (Exception ex)
				{
					errorMessage = ex.Message;
					return;
				}

				// update the session data since user details are updated in the database
				HttpContext.Session.SetString("firstname", Firstname);
				HttpContext.Session.SetString("lastname", Lastname);
				HttpContext.Session.SetString("email", Email);
				HttpContext.Session.SetString("phone", Phone);

				successMessage = "Profile updated correctly";
			}


			else if (submitButton.Equals("password"))
			{
				//validate password and confirm password 
				if (Password == null || Password.Length < 5 || Password.Length > 50)
				{
					errorMessage = "Password length should be between 5 and 50 characters";
					return;
				}

				if (ConfirmPassword == null || !ConfirmPassword.Equals(Password))
				{
					errorMessage = "Password and Confirm Password do not match";
					return;
				}

			}

			// update the password in the database
			try
			{
				using (SqlConnection connection = new SqlConnection(connectionString))
				{
					connection.Open();

					string sql = "UPDATE users SET password=@password WHERE id=@id";

					int? id = HttpContext.Session.GetInt32("id");

					var passwordHasher = new PasswordHasher<IdentityUser>();
					string hashedPassword = passwordHasher.HashPassword(new IdentityUser(), Password);

					using (SqlCommand command = new SqlCommand(sql, connection))
					{
						command.Parameters.AddWithValue("@password", hashedPassword);
						command.Parameters.AddWithValue("@id", id);

						command.ExecuteNonQuery();
					}
				}
			}
			catch (Exception ex)
			{
				errorMessage = ex.Message;
				return;
			}


			successMessage = "Profile Update Successful";

		}
	}

	
}
