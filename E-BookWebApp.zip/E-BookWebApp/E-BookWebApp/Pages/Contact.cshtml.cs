using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using System.ComponentModel.DataAnnotations;
using System.Data.SqlClient;

namespace E_BookWebApp.Pages
{
    public class ContactModel : PageModel
    {
        public void OnGet()
        {
        }
        [BindProperty]
        [Required(ErrorMessage = "The First Name is required")]
        [Display(Name = "FirstName*")]
        public string FirstName { get; set; } = "";

        [BindProperty]
        [Required(ErrorMessage = "The Last Name is required")]
        [Display(Name = "LastName*")]
        public string LastName { get; set; } = "";

        [BindProperty]
        [Required(ErrorMessage = "The   Email Name is required")]
        [EmailAddress]
        [Display(Name = "Email*")]
        public string Email { get; set; } = "";

        [BindProperty]
        public string Phone { get; set; } = "";

        [BindProperty]
        [Required]
        [Display(Name = "Subject*")]
        public string Subject{ get; set; } = "";

        [BindProperty]
        [Required(ErrorMessage = "The Message is required")]
        [MinLength(5, ErrorMessage = "The Message should be at least 5 characters")]
        [MaxLength(1024, ErrorMessage = "The Message should be less than 1024 characters")]
        [Display(Name = "Message*")]
        public string Message { get; set; } = "";

        public List<SelectListItem> SubjectList { get; } = new List<SelectListItem>
        {
            new SelectListItem { Value = "Order Status", Text = "Order Status" },
            new SelectListItem { Value = "Refund Request", Text = "Refund Request" },
            new SelectListItem { Value = "Job Application", Text = "Job Application"  },
            new SelectListItem { Value = "Other", Text = "Other"  },
        };

        public string SuccessMessage { get; set; } = "";
        public string ErrorMessage { get; set; } = "";

        public void Onpost()
        {
            FirstName = Request.Form["firstname"];
            LastName = Request.Form["lastname"];
            Email = Request.Form["email"];
            Phone = Request.Form["phone"];
            Subject = Request.Form["subject"];
            Message = Request.Form["message"];

            //check if required field is empty
            if (FirstName.Length == 0 || LastName.Length == 0 ||
                Email.Length == 0 || Subject.Length == 0 || Message.Length == 0) 

                  {
                //Error 
                ErrorMessage = "Please fill al required fields";
                return;
            }

            // Add this Message to the database

            try
            {
                string connectionString = "Data Source=.\\sqlexpress;Initial Catalog=E-BookWebApp;Integrated Security=True";
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string sql = "INSERT INTO messages " +
                        "(firstname, lastname, email, phone, subject, message) VALUES " +
                        "(@firstname, @lastname, @email, @phone, @subject, @message);";

                    using (SqlCommand command = new SqlCommand(sql, connection))
                    {
                        command.Parameters.AddWithValue("@firstname", FirstName);
                        command.Parameters.AddWithValue("@lastname", LastName);
                        command.Parameters.AddWithValue("@email", Email);
                        command.Parameters.AddWithValue("@phone", Phone);
                        command.Parameters.AddWithValue("@subject", Subject);
                        command.Parameters.AddWithValue("@message", Message);

                        command.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            {
                //Error
                ErrorMessage = ex.Message;
                return;
            }

            //send confirmation Email to the client 

            SuccessMessage = "Your message has beeen recieved correctly";


            FirstName = "";
            LastName = "";
            Email = "";
            Phone = "";
            Subject= "";
            Message= "";

            ModelState.Clear();
        }
    }
}
