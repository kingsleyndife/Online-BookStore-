using E_BookWebApp.Auth_Attributes;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Data.SqlClient;
using static E_BookWebApp.Pages.Staff.OrderModel;
using static E_BookWebApp.Pages.Staff.UsersModel;

namespace E_BookWebApp.Pages.Staff
{

    [RequireAuth(RequiredRole = "admin")]
    public class OrderdetailsModel : PageModel
    {


            public OrderInfo orderInfo = new OrderInfo();
            public UserInfo userInfo = new UserInfo();

            public void OnGet(int id)
            {
                if (id < 1)
                {
                    Response.Redirect("/Staff/Order");
                    return;
                }

                string paymentStatus = Request.Query["payment_status"];
                string orderStatus = Request.Query["order_status"];

                try
                {
                    string connectionString = "Data Source=.\\sqlexpress;Initial Catalog=E-BookWebApp;Integrated Security=True";
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        connection.Open();
                    if (paymentStatus != null)
                    {
                        string sqlUpdate = "UPDATE orders SET payment_status=@payment_status WHERE id=@id";
                        using (SqlCommand command = new SqlCommand(sqlUpdate, connection))
                        {
                            command.Parameters.AddWithValue("@payment_status", paymentStatus);
                            command.Parameters.AddWithValue("@id", id);

                            command.ExecuteNonQuery();
                        }
                    }


                    if (orderStatus != null)
                    {
                        string sqlUpdate = "UPDATE orders SET order_status=@order_status WHERE id=@id";
                        using (SqlCommand command = new SqlCommand(sqlUpdate, connection))
                        {
                            command.Parameters.AddWithValue("@order_status", orderStatus);
                            command.Parameters.AddWithValue("@id", id);

                            command.ExecuteNonQuery();
                        }
                    }


                    string sql = "SELECT * FROM orders WHERE id=@id";
                        using (SqlCommand command = new SqlCommand(sql, connection))
                        {
                            command.Parameters.AddWithValue("@id", id);

                            using (SqlDataReader reader = command.ExecuteReader())
                            {
                                if (reader.Read())
                                {
                                orderInfo.id = reader.GetInt32(0);
                                orderInfo.customer_id = reader.GetInt32(1);
                                orderInfo.orderDate = reader.GetDateTime(2).ToString("MM/dd/yyyy");
                                orderInfo.shippingFee = reader.GetDecimal(3);
                                orderInfo.deliveryAddress = reader.GetString(4);
                                orderInfo.paymentMethod = reader.GetString(5);
                                orderInfo.paymentStatus = reader.GetString(6);
                                orderInfo.orderStatus = reader.GetString(7);

                                orderInfo.items = OrderInfo.getOrderItems(orderInfo.id);
                                }
                                else
                                {
                                    Response.Redirect("/Order");
                                    return;
                                }
                            }
                        }
                        sql = "SELECT * FROM users WHERE id=@id";
                        using (SqlCommand command = new SqlCommand(sql, connection))
                        {
                            command.Parameters.AddWithValue("@id", orderInfo.customer_id);
                            using (SqlDataReader reader = command.ExecuteReader())
                            {
                                if (reader.Read())
                                {
                                    userInfo.id = reader.GetInt32(0);
                                    userInfo.firstname = reader.GetString(1);
                                    userInfo.lastname = reader.GetString(2);
                                    userInfo.email = reader.GetString(3);
                                    userInfo.phone = reader.GetString(4);
                                    //userInfo.deliveryaddress = reader.GetString(5);
                                    userInfo.password = reader.GetString(5);
                                    userInfo.role = reader.GetString(6);
                                    userInfo.created_at = reader.GetDateTime(7).ToString("MM/dd/yyyy");
                                }
                                else
                                {
                                    Console.WriteLine("Customer not found, id=" + orderInfo.customer_id);
                                    Response.Redirect("/Order");
                                    return;
                                }



                            }

                        }
                    }

                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                    Response.Redirect("/Staff/Order");

                }
            }



    }
}

