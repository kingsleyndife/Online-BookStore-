using E_BookWebApp.Auth_Attributes;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.ComponentModel.DataAnnotations;
using System.Data.SqlClient;

namespace E_BookWebApp.Pages.Staff
{
    [RequireAuth(RequiredRole = "admin")]
    public class EditbookModel : PageModel
    {
        [BindProperty]
        public int Id { get; set; }

        [BindProperty]
        [Required(ErrorMessage = "The Title is required")]
        [MaxLength(100, ErrorMessage = "Title cannot exceed 100 characters")]
        public string Title { get; set; } = "";

        [BindProperty]
        [Required(ErrorMessage = "The Author  is required")]
        [MaxLength(255, ErrorMessage = "Author's Name cannot exceed 255 characters")]
        public string Author { get; set; } = "";

        [BindProperty]
        [Required(ErrorMessage = "The Isbn  is required")]
        [MaxLength(20, ErrorMessage = "Isbn  cannot exceed 20 characters")]
        public string Isbn { get; set; } = "";

        [BindProperty]
        [Required(ErrorMessage = "The year of public  is required")]
        public int Publication_year { get; set; }


        [BindProperty]
        [Required(ErrorMessage = "The Price is required")]
        public decimal Price { get; set; }

        [BindProperty]
        [Required]
        public string Genere { get; set; } = "";

        [BindProperty]
        [MaxLength(1000, ErrorMessage = "Description  cannot exceed 20 characters")]
        public string? Description { get; set; } = "";

        [BindProperty]
        [MaxLength(1000, ErrorMessage = "State if bbok is available to users")]
        public string Book_status { get; set; } = "";

        [BindProperty]
        public string ImageFileName { get; set; } = "";

        [BindProperty]
        public IFormFile? ImageFile { get; set; }


        public string errorMessage = "";
        public string successMessage = "";

        private IWebHostEnvironment webHostEnvironment; 
        public EditbookModel(IWebHostEnvironment env ) 
        {

            webHostEnvironment = env;

        }

        public void OnGet()
        {
            string requestId = Request.Query["id"];

            try 
            {
                string connectionString = "Data Source=.\\sqlexpress;Initial Catalog=E-BookWebApp;Integrated Security=True";

                using (SqlConnection connection = new SqlConnection(connectionString)) 
                {
                 connection.Open();

                    string sql = "SELECT * FROM books WHERE id =@id";

                    using (SqlCommand command = new SqlCommand (sql, connection)) 
                    {
                      command.Parameters.AddWithValue ("@id", requestId);
                        using (SqlDataReader reader  = command.ExecuteReader ()) 
                        {
                            if (reader.Read ()) 
                            {
                                Id = reader.GetInt32(0);
                                Title = reader.GetString(1);
                                Author  = reader.GetString(2);
                                Isbn = reader.GetString (3);
                                Publication_year  = reader.GetInt32(4);
                                Price  = reader.GetDecimal(5);
                                Genere = reader.GetString(6);
                                Description  = reader.GetString(7);
                                Book_status = reader.GetString(8);
                                ImageFileName  = reader.GetString(9);



                            }
                            else 
                            {
                                Response.Redirect("/Staff/Booklistpage");
                            
                            }


                        }
                    
                    }
                
                }
            
            }
            catch (Exception ex) 
            {
                Console.WriteLine(ex.Message);
                Response.Redirect("/Staff/Booklistpage");
            }


        }
        public void OnPost() 
        {
         if (!ModelState.IsValid) 
         {
                foreach (var modelStateEntry in ModelState)
                {
                    foreach (var error in modelStateEntry.Value.Errors)
                    {
                        errorMessage += $"{modelStateEntry.Key}: {error.ErrorMessage}\n";
                    }
                }
                return;
            }
            //sucessful data validation 

            if (Description == null) Description = "";

            //if we have a new ImageFile => upload the new image and delete the old image 
            string newFileName = ImageFileName;
            if (ImageFile != null)
            {
                newFileName = DateTime.Now.ToString("yyyyMMddHHmmssfff");
                newFileName += Path.GetExtension(ImageFile.FileName);

                string imageFolder = webHostEnvironment.WebRootPath + "/Pictures/Bookimages/";
                string imageFullPath = Path.Combine(imageFolder, newFileName);
                Console.WriteLine("New image (Edit): " + imageFullPath);

                using (var stream = System.IO.File.Create(imageFullPath))
                {
                    ImageFile.CopyToAsync(stream);
                }

                // delete old image
                string oldImageFullPath = Path.Combine(imageFolder, ImageFileName);
                System.IO.File.Delete(oldImageFullPath);
                Console.WriteLine("Delete Image " + oldImageFullPath);
            }

            //update the book in the database 
            try
            {
                string connectionString = "Data Source=.\\sqlexpress;Initial Catalog=E-BookWebApp;Integrated Security=True";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string sql = "UPDATE books SET title=@title, author=@author, isbn=@isbn, " +
                        "publication_year=@publication_year, price=@price, genere=@genere, " +
                        "description=@description,book_status=@book_status, image_filename=@image_filename WHERE id=@id;";

                    using (SqlCommand command = new SqlCommand(sql, connection))
                    {
                        command.Parameters.AddWithValue("@title", Title);
                        command.Parameters.AddWithValue("@author", Author);
                        command.Parameters.AddWithValue("@isbn", Isbn);
                        command.Parameters.AddWithValue("@publication_year", Publication_year);
                        command.Parameters.AddWithValue("@price", Price);
                        command.Parameters.AddWithValue("@genere", Genere);
                        command.Parameters.AddWithValue("@description", Description);
                        command.Parameters.AddWithValue("@book_status", Book_status);
                        command.Parameters.AddWithValue("@image_filename", newFileName);
                        command.Parameters.AddWithValue("@id", Id);

                        command.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            {
                errorMessage = ex.Message;
                return;
            }

            successMessage = "Data save successful";
            Response.Redirect("/Staff/Booklistpage");
        }
    }
}
