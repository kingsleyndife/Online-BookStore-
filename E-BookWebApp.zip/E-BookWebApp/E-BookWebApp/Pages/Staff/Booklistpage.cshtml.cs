using E_BookWebApp.Auth_Attributes;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Data.SqlClient;

namespace E_BookWebApp.Pages.Staff
{
    [RequireAuth(RequiredRole = "admin")]
    public class BooklistpageModel : PageModel
    {
        public List<BookInfo> listBooks = new List<BookInfo>();

        public string search = "";

        public string column = "id";
        public string order = "asc";

        public void OnGet()
        {
            search = Request.Query["search"];
            if (search == null) search = "";

            string[] validColumns = { "id", "title", "genere" };
            column = Request.Query["column"];

            if (column == null || !validColumns.Contains(column))
            {
                column = "id";
            }

            order = Request.Query["order"];
            if (order == null || !order.Equals("asc"))
            {
                order = "asc";
            }


            try
            {
                string connectionstring = "Data Source=.\\sqlexpress;Initial Catalog=E-BookWebApp;Integrated Security=True";

                using (SqlConnection connection = new SqlConnection(connectionstring))
                {
                    connection.Open();

                    string sql = "SElECT * FROM books";
                    if (search.Length > 0)
                    {
                        sql += " WHERE title LIKE @search OR author LIKE @search ";
                    
                    }
                    sql += " ORDER BY " + column + " " + order; //" ORDER BY id DESC";

                    using (SqlCommand command = new SqlCommand(sql, connection))
                    {
                        command.Parameters.AddWithValue("@search","%" +search + "%");


                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                BookInfo bookInfo = new BookInfo();
                                bookInfo.Id = reader.GetInt32(0);
                                bookInfo.Title = reader.GetString(1);
                                bookInfo.Author = reader.GetString(2);
                                bookInfo.Isbn = reader.GetString(3);
                                bookInfo.Publication_year = reader.GetInt32(4);
                                bookInfo.Price = reader.GetDecimal(5);
                                bookInfo.Genere = reader.GetString(6);
                                bookInfo.Description = reader.GetString(7);
                                bookInfo.Book_status = reader.GetString(8);
                                bookInfo.Image_filename = reader.GetString(9);
                                bookInfo.Created_at = reader.GetDateTime(10).ToString("MM/dd/yyyy");

                                listBooks.Add(bookInfo);
                            }

                        }
                    }
                }

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);

            }
        }


    }
    public class BookInfo 
    {
        public int Id { get; set; }
        public string Title { get; set; } = "";
        public string Author { get; set; } = "";

        public string Isbn { get; set; } = "";
        public int Publication_year { get; set; } 
        public decimal Price { get; set; } 
        public string Genere { get; set; } = "";
        public string Description  { get; set; } = "";
        public string Book_status { get; set; } = "";
        public string Image_filename { get; set; } = "";
        public string  Created_at { get; set; } = "";



    }
}
