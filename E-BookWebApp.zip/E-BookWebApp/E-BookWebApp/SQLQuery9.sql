﻿CREATE TABLE books (
    bookid INT NOT NULL PRIMARY KEY IDENTITY,
    title VARCHAR (100) NOT NULL,
    author VARCHAR (255) NOT NULL,
    isbn VARCHAR(20) NOT NULL,
	publication_year INT NOT NULL,
	price DECIMAL (16, 2) NOT NULL,
    genere VARCHAR(100) NOT NULL,
    description TEXT NOT NULL,
    book_status VARCHAR (255)NOT NULL,
	image_filename VARCHAR (255) NOT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);
INSERT INTO books (title, author, isbn, Publication_year, price, genere, description,book_status, image_filename)
VALUES
('Data Science', 'Vance Williams', '2456789305X', 2000, 25.8, ' Science', '','Available','9781913597467.jpg'),
('The 48 Laws of power ', 'Robert Greene', '2359146467M', 2013, 96.4, 'Philosophy ', '', 'Available','1130151268-image.jpg'),
('The American Dream ', ' Gary SIrak', '231404249M', 2012, 38.2, 'Society', '', 'Available', 'R.jpg'),

('One and Only', 'Jenny Holiday ', '013162959X', 2003, 99.9, 'Romance ', '', 'Available', 'R (1).jpg'),
('The Last Girl ', 'Susan Ward', '0760034397', 2005, 75.0, 'Romance', '', 'Available', 'the-last-girl2-amazon_orig.jpg');
